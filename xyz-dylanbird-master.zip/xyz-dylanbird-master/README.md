# xyz-dylanbird

[![Netlify Status](https://api.netlify.com/api/v1/badges/64a959ad-b3f4-4451-9f05-a9fbb7e378d1/deploy-status)](https://app.netlify.com/sites/dylanbird/deploys)

Repo for personal website using Jekyll for build, AWS route 53 for domain registration and Netlify for DNS hosting and deployment.

